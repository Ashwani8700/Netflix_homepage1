This is a Netflix homepage clone 
--TARUN--	

1. I have used raw videos from the original NETFLIX HOMEPAGE.
2. This website is made using html and css only.
3. Only the webpage is created so far.